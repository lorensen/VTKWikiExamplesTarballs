#include <vtkSmartPointer.h>

#include <vtkTensorGlyph.h>

#include <vtkActor.h>
#include <vtkProperty.h>
#include <vtkCamera.h>
#include <vtkConeSource.h>
#include <vtkImageDataGeometryFilter.h>
#include <vtkLogLookupTable.h>
#include <vtkOutlineFilter.h>
#include <vtkPointLoad.h>
#include <vtkPolyDataNormals.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSphereSource.h>

#include <vtkNamedColors.h>
int main (int argc, char *argv[])
{
  vtkSmartPointer<vtkNamedColors> colors =
    vtkSmartPointer<vtkNamedColors>::New();

// Create tensor ellipsoids
//
// Generate tensors
  vtkSmartPointer<vtkPointLoad> ptLoad =
    vtkSmartPointer<vtkPointLoad>::New();
  ptLoad->SetLoadValue(100.0);
  ptLoad->SetSampleDimensions(6,6,6);
  ptLoad->ComputeEffectiveStressOn();
  ptLoad->SetModelBounds(-10,10,-10,10,-10,10);

// Extract plane of data
  vtkSmartPointer<vtkImageDataGeometryFilter> plane =
    vtkSmartPointer<vtkImageDataGeometryFilter>::New();
  plane->SetInputConnection(ptLoad->GetOutputPort());
  plane->SetExtent(2,2,0,99,0,99);

// Generate ellipsoids
  vtkSmartPointer<vtkSphereSource> sphere =
    vtkSmartPointer<vtkSphereSource>::New();
  sphere->SetThetaResolution(8);
  sphere->SetPhiResolution(8);

  vtkSmartPointer<vtkTensorGlyph> ellipsoids =
    vtkSmartPointer<vtkTensorGlyph>::New();
  ellipsoids->SetInputConnection(ptLoad->GetOutputPort());
  ellipsoids->SetSourceConnection(sphere->GetOutputPort());
  ellipsoids->SetScaleFactor(10);
  ellipsoids->ClampScalingOn();

  vtkSmartPointer<vtkPolyDataNormals> ellipNormals =
    vtkSmartPointer<vtkPolyDataNormals>::New();
  ellipNormals->SetInputConnection(ellipsoids->GetOutputPort());

// Map contour
  vtkSmartPointer<vtkLogLookupTable> lut =
    vtkSmartPointer<vtkLogLookupTable>::New();
  lut->SetHueRange(.6667,0.0);

  vtkSmartPointer<vtkPolyDataMapper> ellipMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  ellipMapper->SetInputConnection(ellipNormals->GetOutputPort());
  ellipMapper->SetLookupTable(lut);

// Force update for scalar range
  plane->Update();
  ellipMapper->SetScalarRange(plane->GetOutput()->GetScalarRange());

  vtkSmartPointer<vtkActor> ellipActor =
    vtkSmartPointer<vtkActor>::New();
  ellipActor->SetMapper(ellipMapper);

// Create outline around data
  vtkSmartPointer<vtkOutlineFilter> outline =
    vtkSmartPointer<vtkOutlineFilter>::New();
  outline->SetInputConnection(ptLoad->GetOutputPort());

  vtkSmartPointer<vtkPolyDataMapper> outlineMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  outlineMapper->SetInputConnection(outline->GetOutputPort());

  vtkSmartPointer<vtkActor> outlineActor =
    vtkSmartPointer<vtkActor>::New();
  outlineActor->SetMapper(outlineMapper);
  outlineActor->GetProperty()->SetColor(0.0,0.0,0.0);

// Create cone indicating application of load
  vtkSmartPointer<vtkConeSource> coneSrc =
    vtkSmartPointer<vtkConeSource>::New();
  coneSrc->SetRadius(.5);
  coneSrc->SetHeight(2);
  vtkSmartPointer<vtkPolyDataMapper> coneMap =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  coneMap->SetInputConnection(coneSrc->GetOutputPort());
  
  vtkSmartPointer<vtkActor> coneActor =
    vtkSmartPointer<vtkActor>::New();
  coneActor->SetMapper(coneMap);
  coneActor->SetPosition(0,0,11);
  coneActor->RotateY(90);
  coneActor->GetProperty()->SetColor(1,0,0);

  vtkSmartPointer<vtkCamera> camera =
    vtkSmartPointer<vtkCamera>::New();
  camera->SetFocalPoint(0.0, 0.0, 0.0);
  camera->SetPosition(1.0, 0.0, 0.0);
  camera->SetViewUp(0.0, 0.0, 1.0);
  camera->Azimuth(30);
  camera->Elevation(30);
  
// Create the RenderWindow, Renderer and interactive renderer
  vtkSmartPointer<vtkRenderer> renderer =
    vtkSmartPointer<vtkRenderer>::New();

  vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->SetMultiSamples(0);
  renderWindow->AddRenderer(renderer);

  vtkSmartPointer<vtkRenderWindowInteractor> interactor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  interactor->SetRenderWindow(renderWindow);

  renderer->AddActor(ellipActor);
  renderer->AddActor(outlineActor);
  renderer->AddActor(coneActor);
  renderer->SetBackground(colors->GetColor3d("Gainsboro").GetData());
  renderer->SetActiveCamera(camera);
  renderer->ResetCamera();

  renderWindow->SetSize(400,400);
  renderWindow->Render();

  interactor->Start();
  return EXIT_SUCCESS;
}
