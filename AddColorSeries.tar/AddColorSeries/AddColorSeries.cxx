#include <vtkSmartPointer.h>
#include <vtkColorSeries.h>

#include <vtkNamedColors.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>

#include <vtkLookupTable.h>
#include <vtkFloatArray.h>
#include <vtkCellData.h>
#include <vtkPolyData.h>
#include <vtkPlaneSource.h>

#include <map>
#include <vector>
#include <string>

int main (int argc, char *argv[])
{
  vtkSmartPointer<vtkColorSeries> myColors =
    vtkSmartPointer<vtkColorSeries>::New();
  myColors->SetColorSchemeByName("myBlueColors");
  myColors->AddColor(vtkColor3ub(240,  248,  255)); // alice_blue
  myColors->AddColor(vtkColor3ub(  0,    0,  255)); // blue 
  myColors->AddColor(vtkColor3ub(173,  216,  230)); // blue_light 
  myColors->AddColor(vtkColor3ub( 0,    0,  205)); // blue_medium 
  myColors->AddColor(vtkColor3ub(95,  158,  160)); // cadet 
  myColors->AddColor(vtkColor3ub(61,   89,  171)); // cobalt 
  myColors->AddColor(vtkColor3ub(100,  149,  237)); // cornflower 
  myColors->AddColor(vtkColor3ub( 5,  184,  204)); // cerulean 
  myColors->AddColor(vtkColor3ub(30,  144,  255)); // dodger_blue 
  myColors->AddColor(vtkColor3ub(75,    0,  130)); // indigo 
  myColors->AddColor(vtkColor3ub( 3,  168,  158)); // manganese_blue 
  myColors->AddColor(vtkColor3ub(25,   25,  112)); // midnight_blue 
  myColors->AddColor(vtkColor3ub( 0,    0,  128)); // navy 
  myColors->AddColor(vtkColor3ub(51,  161,  201)); // peacock 
  myColors->AddColor(vtkColor3ub(176,  224,  230)); // powder_blue 
  myColors->AddColor(vtkColor3ub(65,  105,  225)); // royal_blue 
  myColors->AddColor(vtkColor3ub(106,   90,  205)); // slate_blue 
  myColors->AddColor(vtkColor3ub(72,   61,  139)); // slate_blue_dark 
  myColors->AddColor(vtkColor3ub(132,  112,  255)); // slate_blue_light 
  myColors->AddColor(vtkColor3ub(123,  104,  238)); // slate_blue_medium 
  myColors->AddColor(vtkColor3ub(135,  206,  235)); // sky_blue 
  myColors->AddColor(vtkColor3ub(0,  191,  255)); // sky_blue_deep 
  myColors->AddColor(vtkColor3ub(135,  206,  250)); // sky_blue_light 
  myColors->AddColor(vtkColor3ub(70,  130,  180)); // steel_blue 
  myColors->AddColor(vtkColor3ub(176,  196,  222)); // steel_blue_light 
  myColors->AddColor(vtkColor3ub(0,  199,  140)); // turquoise_blue 
  myColors->AddColor(vtkColor3ub(18,   10,  143)); // ultramarine 
  int numberOfColors = myColors->GetNumberOfColors();
  std::cout << "Number of colors: " << numberOfColors << std::endl;  
  vtkSmartPointer<vtkLookupTable> lut =
    myColors->CreateLookupTable();

  // Provide some geometry
  int resolution = 6;
  vtkSmartPointer<vtkPlaneSource> aPlane =
    vtkSmartPointer<vtkPlaneSource>::New();
  aPlane->SetXResolution(resolution);
  aPlane->SetYResolution(resolution);

  // Create cell data
  vtkSmartPointer<vtkFloatArray> cellData =
    vtkSmartPointer<vtkFloatArray>::New();
  for (int i = 0; i < resolution * resolution; i++)
  {
    cellData->InsertNextValue(i + 1);
  }
  aPlane->Update();
  aPlane->GetOutput()->GetCellData()->SetScalars(cellData);

  vtkSmartPointer<vtkNamedColors> colors =
    vtkSmartPointer<vtkNamedColors>::New();

  // Setup actor and mapper
  vtkSmartPointer<vtkPolyDataMapper> mapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper->SetInputConnection(aPlane->GetOutputPort());
  mapper->SetScalarRange(0, numberOfColors - 1);
  mapper->SetLookupTable(lut);

  vtkSmartPointer<vtkActor> actor =
    vtkSmartPointer<vtkActor>::New();
  actor->SetMapper(mapper);

  // Setup render window, renderer, and interactor
  vtkSmartPointer<vtkRenderer> renderer =
    vtkSmartPointer<vtkRenderer>::New();
  vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
      vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);
  renderer->AddActor(actor);
  renderer->SetBackground(colors->GetColor3d("SlateGray").GetData());
  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
