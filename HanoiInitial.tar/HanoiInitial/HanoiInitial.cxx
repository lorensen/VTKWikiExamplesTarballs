// Start this program with the parameter: -c 1
#include "Hanoi.cxx"
