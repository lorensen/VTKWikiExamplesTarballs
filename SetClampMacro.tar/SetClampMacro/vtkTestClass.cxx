#include "vtkTestClass.h"

#include "vtkObjectFactory.h"
#include "vtkStreamingDemandDrivenPipeline.h"
#include "vtkInformationVector.h"
#include "vtkInformation.h"
#include "vtkDataObject.h"
#include "vtkSmartPointer.h"

vtkCxxRevisionMacro(vtkTestClass, "$Revision: 1.70 $");
vtkStandardNewMacro(vtkTestClass);
