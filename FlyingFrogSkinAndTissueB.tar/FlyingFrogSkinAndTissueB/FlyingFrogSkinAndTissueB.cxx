// This file is used for tests.
// Generates Figure 12-9b from the VTK textbook.
#include "FlyingFrogSkinAndTissue.cxx"
