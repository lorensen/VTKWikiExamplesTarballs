#include <vtkPolyData.h>

int main(int, char *[])
{

  return EXIT_SUCCESS;
}
