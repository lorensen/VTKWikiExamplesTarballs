#include <vtkSmartPointer.h>
#include <vtkImageCanvasSource2D.h>
#include <vtkPNGWriter.h>

int main (int argc, char *argv[])
{
  vtkSmartPointer<vtkImageCanvasSource2D> imageCanvas =
    vtkSmartPointer<vtkImageCanvasSource2D>::New();

  imageCanvas->SetScalarTypeToUnsignedChar();
  imageCanvas->SetExtent(1, 256, 1, 256, 0, 0);
  imageCanvas->SetDrawColor(0.0);
  imageCanvas->FillBox(1, 256, 1, 256);
  imageCanvas->SetDrawColor(255.0);
  imageCanvas->FillBox(30, 225, 30, 225);
  imageCanvas->SetDrawColor(0.0);
  imageCanvas->FillBox(60, 195, 60, 195);
  imageCanvas->SetDrawColor(255.0);
  imageCanvas->FillTube(100, 100, 154, 154, 40.0);
  imageCanvas->SetDrawColor(0.0);
  imageCanvas->DrawSegment(45, 45, 45, 210);
  imageCanvas->DrawSegment(45, 210, 210, 210);
  imageCanvas->DrawSegment(210, 210, 210, 45);
  imageCanvas->DrawSegment(210, 45, 45, 45);
  imageCanvas->DrawSegment(100, 150, 150, 100);
  imageCanvas->DrawSegment(110, 160, 160, 110);
  imageCanvas->DrawSegment(90, 140, 140, 90);
  imageCanvas->DrawSegment(120, 170, 170, 120);
  imageCanvas->DrawSegment(80, 130, 130, 80);
  imageCanvas->Update();
  
  vtkSmartPointer<vtkPNGWriter> writer =
    vtkSmartPointer<vtkPNGWriter>::New();
  writer->SetInputConnection(imageCanvas->GetOutputPort());
  writer->SetFileName(argv[1]);
  writer->Write();
  return EXIT_SUCCESS;
  }
