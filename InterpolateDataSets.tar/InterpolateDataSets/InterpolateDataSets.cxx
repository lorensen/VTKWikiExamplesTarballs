#include <vtkSmartPointer.h>

#include <vtkActor.h>
#include <vtkCompositeDataGeometryFilter.h>
#include <vtkDataSetMapper.h>
#include <vtkExodusIIReader.h>
#include <vtkGaussianKernel.h>
#include <vtkInterpolateDataSetAttributes.h>
#include <vtkPointInterpolator.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkRenderer.h>
#include <vtkStaticPointLocator.h>
#include <vtkUnstructuredGrid.h>
#include <vtkMultiBlockDataSet.h>

int main (int argc, char *argv[])
{
  std::string file0 = argv[1];
  std::string file1 = argv[2];
  std::string variable = "u";
  double range[2] = {0, 10};

   ///////////////////////////////////////////////////////////////////////////
    // FILE 0: COARSE MESH WITH SOLUTION 0
    vtkSmartPointer<vtkExodusIIReader> reader0 =
      vtkSmartPointer<vtkExodusIIReader>::New();
    reader0->SetFileName(file0.c_str());
    reader0->UpdateInformation();
    reader0->SetTimeStep(0);
    reader0->SetAllArrayStatus(vtkExodusIIReader::NODAL, 1);
    reader0->Update();

    vtkSmartPointer<vtkCompositeDataGeometryFilter> geometry0 =
      vtkSmartPointer<vtkCompositeDataGeometryFilter>::New();
    geometry0->SetInputConnection(0, reader0->GetOutputPort(0));
    geometry0->Update();

    vtkSmartPointer<vtkPolyDataMapper> mapper0 =
      vtkSmartPointer<vtkPolyDataMapper>::New();
    mapper0->SetInputConnection(geometry0->GetOutputPort());
    mapper0->SelectColorArray(variable.c_str());
    mapper0->SetScalarModeToUsePointFieldData();
    mapper0->InterpolateScalarsBeforeMappingOn();
    mapper0->SetScalarRange(range);

    vtkSmartPointer<vtkActor> actor0 =
      vtkSmartPointer<vtkActor>::New();
    actor0->SetMapper(mapper0);
    actor0->GetProperty()->SetEdgeVisibility(true);

    vtkSmartPointer<vtkRenderer> renderer0 =
      vtkSmartPointer<vtkRenderer>::New();
    renderer0->AddViewProp(actor0);
    renderer0->SetViewport(0, 0, 0.25, 1);

/////////////////////////////////////////////////////////////////////
// FILE 1: FINE MESH WITH SOLUTION 1

    vtkSmartPointer<vtkExodusIIReader> reader1 =
      vtkSmartPointer<vtkExodusIIReader>::New();
    reader1->SetFileName(file1.c_str());
    reader1->UpdateInformation();
    reader1->SetTimeStep(0);
    reader1->SetAllArrayStatus(vtkExodusIIReader::NODAL, 1);
    reader1->Update();

    vtkSmartPointer<vtkCompositeDataGeometryFilter> geometry1 =
      vtkSmartPointer<vtkCompositeDataGeometryFilter>::New();
    geometry1->SetInputConnection(0, reader1->GetOutputPort(0));
    geometry1->Update();

    vtkSmartPointer<vtkPolyDataMapper> mapper1 =
      vtkSmartPointer<vtkPolyDataMapper>::New();
    mapper1->SetInputConnection(geometry1->GetOutputPort());
    mapper1->SelectColorArray(variable.c_str());
    mapper1->SetScalarModeToUsePointFieldData();
    mapper1->InterpolateScalarsBeforeMappingOn();
    mapper1->SetScalarRange(range);

    vtkSmartPointer<vtkActor> actor1 =
      vtkSmartPointer<vtkActor>::New();
    actor1->SetMapper(mapper1);
    actor1->GetProperty()->SetEdgeVisibility(true);

    vtkSmartPointer<vtkRenderer> renderer1 =
      vtkSmartPointer<vtkRenderer>::New();
    renderer1->AddViewProp(actor1);
    renderer1->SetViewport(0.75, 0, 1, 1);

//////////////////////////////////////////////////////////////////////
// PROJECT SOLUTION FROM FILE 0 to GRID FROM FILE 1

// Get the data to be interpolated
    vtkUnstructuredGrid *source_data =
      vtkUnstructuredGrid::SafeDownCast(reader0->GetOutput()->GetBlock(0)); // Pc data from file 0 (filter source);

// Build the structure to interpolate on to
    vtkSmartPointer<vtkUnstructuredGrid> output_grid = // output to be interpolated on to
    vtkSmartPointer<vtkUnstructuredGrid>::New();
//output_grid->DeepCopy(reader1->GetOutput()->GetBlock(0)->GetBlock(0))
    reader1->GetOutput()->GetBlock(0)->Print(std::cout);
    output_grid->DeepCopy(vtkUnstructuredGrid::SafeDownCast(reader1->GetOutput()->GetBlock(0)));

    vtkSmartPointer<vtkStaticPointLocator> locator =
      vtkSmartPointer<vtkStaticPointLocator>::New();
    locator->SetDataSet(output_grid);
    locator->BuildLocator();

    vtkSmartPointer<vtkGaussianKernel> kernel =
      vtkSmartPointer<vtkGaussianKernel>::New();
    kernel->SetSharpness(4);

    vtkSmartPointer<vtkPointInterpolator> interpolator =
      vtkSmartPointer<vtkPointInterpolator>::New();

    interpolator->SetSourceData(source_data); // Pc data set to be probed by input points P
interpolator->SetInputData(output_grid);
interpolator->SetKernel(kernel);
interpolator->SetLocator(locator);
interpolator->SetNullPointsStrategyToClosestPoint();
interpolator->Update();

//geometry2 = vtk->vtkCompositeDataGeometryFilter()
//geometry2->SetInputConnection(0, interpolator->GetOutputPort())
//geometry2->Update()

//mapper2 = vtk.vtkPolyDataMapper()
    vtkSmartPointer<vtkDataSetMapper> mapper2 =
      vtkSmartPointer<vtkDataSetMapper>::New();
    mapper2->SetInputConnection(interpolator->GetOutputPort());
    mapper2->SelectColorArray(variable.c_str());
    mapper2->SetScalarModeToUsePointFieldData();
    mapper2->InterpolateScalarsBeforeMappingOn();
    mapper2->SetScalarRange(range);

    vtkSmartPointer<vtkActor> actor2 =
      vtkSmartPointer<vtkActor>::New();
    actor2->SetMapper(mapper2);
    actor2->GetProperty()->SetEdgeVisibility(true);

    vtkSmartPointer<vtkRenderer> renderer2 =
      vtkSmartPointer<vtkRenderer>::New();
    renderer2->AddActor(actor2);
    renderer2->SetViewport(0.25, 0, 0.5, 1);

    // I cannot get this to perform interpolation
    vtkSmartPointer<vtkInterpolateDataSetAttributes> data =
      vtkSmartPointer<vtkInterpolateDataSetAttributes>::New();
    data->AddInputData(0, reader1->GetOutput()->GetBlock(0));
    data->AddInputData(1, interpolator->GetOutput());
    data->SetT(0.5);
    data->Update();

    vtkSmartPointer<vtkDataSetMapper> mapper3 =
      vtkSmartPointer<vtkDataSetMapper>::New();
    mapper3->SetInputConnection(data->GetOutputPort());
    mapper3->SelectColorArray(variable.c_str());
    mapper3->SetScalarModeToUsePointFieldData();
    mapper3->InterpolateScalarsBeforeMappingOn();
    mapper3->SetScalarRange(range);

    vtkSmartPointer<vtkActor> actor3 =
      vtkSmartPointer<vtkActor>::New();
    actor3->SetMapper(mapper3);
    actor3->GetProperty()->SetEdgeVisibility(true);

    vtkSmartPointer<vtkRenderer> renderer3 =
      vtkSmartPointer<vtkRenderer>::New();
    renderer3->AddActor(actor3);
    renderer3->SetViewport(0.5, 0, 0.75, 1);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Window and Interactor

    vtkSmartPointer<vtkRenderWindow> window =
      vtkSmartPointer<vtkRenderWindow>::New();
    window->AddRenderer(renderer0);
    window->AddRenderer(renderer2);
    window->AddRenderer(renderer3);
    window->AddRenderer(renderer1);
    window->SetSize(1280, 1024);

    vtkSmartPointer<vtkRenderWindowInteractor> interactor =
      vtkSmartPointer<vtkRenderWindowInteractor>::New();
    interactor->SetRenderWindow(window);
    interactor->Initialize();

    window->Render();
    interactor->Start();
}
