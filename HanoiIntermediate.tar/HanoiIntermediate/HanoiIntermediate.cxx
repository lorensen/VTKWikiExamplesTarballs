// Start this program with the parameter: -c 2
#include "Hanoi.cxx"
