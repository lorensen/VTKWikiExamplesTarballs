#include <vtkSmartPointer.h>

#include <vtkBYUReader.h>
#include <vtkOBJReader.h>
#include <vtkPLYReader.h>
#include <vtkPolyDataReader.h>
#include <vtkSTLReader.h>
#include <vtkXMLPolyDataReader.h>
#include <vtkSphereSource.h>
#include <vtksys/SystemTools.hxx>

#include <vtkImplicitPolyDataDistance.h>
#include <vtkSampleFunction.h>
#include <vtkClipVolume.h>
#include <vtkPolyDataNormals.h>
#include <vtkImageData.h>

#include <vtkActor.h>
#include <vtkDataSetMapper.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkCamera.h>

#include <vtkNamedColors.h>
#include <array>
#include <string>

namespace
{
vtkSmartPointer<vtkPolyData> ReadPolyData(const char *fileName);
}

int main (int argc, char *argv[])
{
  vtkSmartPointer<vtkPolyData> polyData = ReadPolyData(argc > 1 ? argv[1] : "");;

  auto normals =
    vtkSmartPointer<vtkPolyDataNormals>::New();
  normals->SetInputData(polyData);
  normals->Update();

  // create a volume of distances to the input polydata
  auto implicitFunction =
    vtkSmartPointer<vtkImplicitPolyDataDistance>::New();
  implicitFunction->SetInput(normals->GetOutput());
  implicitFunction->SetInput(polyData);

  std::array<double, 6> bounds;
  polyData->GetBounds(bounds.data());
  std::array<double, 3> range;
  for (int i = 0; i < 3; ++i)
  {
    range[i] = bounds[2 * i + 1] - bounds[2 * i];
  }
  double maxRange = std::max(std::max(range[0], range[1]), range[2]);
  std::cout << "maxRange: " << maxRange << std::endl;

  auto sampleFunction =
    vtkSmartPointer<vtkSampleFunction>::New();
  sampleFunction->SetSampleDimensions(64, 64, 64);
  sampleFunction->SetSampleDimensions(128, 128, 128);
  sampleFunction->SetModelBounds(
    bounds[0] - .1 * maxRange, bounds[1] + .1 * maxRange,
    bounds[2] - .1 * maxRange, bounds[3] + .1 * maxRange,
    bounds[4] - .1 * maxRange, bounds[1] + .1 * maxRange);
  sampleFunction->SetImplicitFunction(implicitFunction);
  sampleFunction->Update();

  auto clipVolume =
    vtkSmartPointer<vtkClipVolume>::New();
  clipVolume->SetValue(maxRange * .01);
  clipVolume->SetInputData(sampleFunction->GetOutput());
  clipVolume->InsideOutOn();

  // Visualize
  auto colors =
    vtkSmartPointer<vtkNamedColors>::New();

  auto mapper =
    vtkSmartPointer<vtkDataSetMapper>::New();
  mapper->SetInputConnection(clipVolume->GetOutputPort());

  auto backProp =
    vtkSmartPointer<vtkProperty>::New();
  backProp->SetDiffuseColor(colors->GetColor3d("Banana").GetData());
  backProp->SetSpecular(.6);
  backProp->SetSpecularPower(30);

  auto actor =
    vtkSmartPointer<vtkActor>::New();
  actor->SetMapper(mapper);
  actor->SetBackfaceProperty(backProp);
  actor->GetProperty()->SetDiffuseColor(colors->GetColor3d("Crimson").GetData());
  actor->GetProperty()->SetSpecular(.6);
  actor->GetProperty()->SetSpecularPower(30);

  auto renderer =
    vtkSmartPointer<vtkRenderer>::New();
  auto renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  auto renderWindowInteractor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);

  renderer->AddActor(actor);
  renderer->SetBackground(colors->GetColor3d("Silver").GetData());
  renderer->UseHiddenLineRemovalOn();

  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}

namespace
{
vtkSmartPointer<vtkPolyData> ReadPolyData(const char *fileName)
{
  vtkSmartPointer<vtkPolyData> polyData;
  auto extension = vtksys::SystemTools::GetFilenameLastExtension(std::string(fileName));
  if (extension == ".ply")
  {
    auto reader =
      vtkSmartPointer<vtkPLYReader>::New();
    reader->SetFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtp")
  {
    auto reader =
      vtkSmartPointer<vtkXMLPolyDataReader>::New();
    reader->SetFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".obj")
  {
    auto reader =
      vtkSmartPointer<vtkOBJReader>::New();
    reader->SetFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".stl")
  {
    auto reader =
      vtkSmartPointer<vtkSTLReader>::New();
    reader->SetFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtk")
  {
    auto reader =
      vtkSmartPointer<vtkPolyDataReader>::New();
    reader->SetFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".g")
  {
    auto reader =
      vtkSmartPointer<vtkBYUReader>::New();
    reader->SetGeometryFileName (fileName);
    reader->Update();
    polyData = reader->GetOutput();
  }
  else
  {
    auto source =
      vtkSmartPointer<vtkSphereSource>::New();
    source->Update();
    polyData = source->GetOutput();
  }
  return polyData;
}
}
