#include <vtkSmartPointer.h>

#include <vtkOBBTree.h>
#include <vtkMatrix4x4.h>
#include <vtkTransform.h>
#include <vtkTransformPolyDataFilter.h>
#include <vtkTubeFilter.h>
#include <vtkLineSource.h>
#include <vtkBoundingBox.h>

#include <vtkNamedColors.h>

#include <vtkActor.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>

// Readers
#include <vtkBYUReader.h>
#include <vtkOBJReader.h>
#include <vtkPLYReader.h>
#include <vtkPolyDataReader.h>
#include <vtkSTLReader.h>
#include <vtkXMLPolyDataReader.h>

#include <vtkPolyData.h>
#include <vtkSphereSource.h>

#include <algorithm> // For transform()
#include <string> // For find_last_of()
#include <cctype> // For to_lower
#include <algorithm> // for max_element
#include <array>

namespace {
vtkSmartPointer<vtkPolyData> ReadPolyData(std::string const& fileName);
}

int main (int argc, char *argv[])
{
  auto polyData = ReadPolyData(argc > 1 ? argv[1] : "");;

  // Get bounds of polydata
  std::array<double, 6> bounds;
  polyData->GetBounds(bounds.data());

  vtkBoundingBox bbox(bounds.data());;
  std::array<double, 3> lengths;
  bbox.GetLengths(lengths.data());

  auto length = bbox.GetMaxLength();
  std::cout << "length: "<< length << std::endl;

  // Find long axis
  int longAxis;
  for (auto i = 0; i < 3; ++i)
  {
    if (length == lengths[i])
    {
      longAxis = i;
      break;
    }
  }
  std::cout << "longAxis: " << longAxis << std::endl;

  // Find center of face
  std::array<double,3> point1;
  std::array<double,3> point2;
  std::array<double,3> center;
  if (longAxis == 0)
  {
    center[0] = bounds[0];
    center[1] = bounds[2] + (bounds[3] - bounds[2]) / 2.0;
    center[2] = bounds[4] + (bounds[5] - bounds[4]) / 2.0;
  }
  else if (longAxis == 1)
  {
    center[0] = (bounds[1] + bounds[0]) / 2.0;
    center[1] = bounds[2];
    center[2] = (bounds[5] + bounds[4]) / 2.0;
  }
  else
  {
    center[0] = (bounds[1] + bounds[0]) / 2.0;
    center[1] = (bounds[3] + bounds[2]) / 2.0;
    center[2] = bounds[4];
  }
  std::array<double,3> radii;
  point1[0] = bounds[0]; point1[1] = bounds[2]; point1[2] = bounds[4];
  point2[0] = bounds[0]; point2[1] = bounds[3]; point2[2] = bounds[5];
  radii[0] = std::sqrt(vtkMath::Distance2BetweenPoints(point1.data(), point2.data()));
  point1[0] = bounds[0]; point1[1] = bounds[2]; point1[2] = bounds[4];
  point2[0] = bounds[1]; point2[1] = bounds[3]; point2[2] = bounds[4];
  radii[1] = std::sqrt(vtkMath::Distance2BetweenPoints(point1.data(), point2.data()));
  point1[0] = bounds[0]; point1[1] = bounds[2]; point1[2] = bounds[4];
  point2[0] = bounds[1]; point2[1] = bounds[3]; point2[2] = bounds[5];
  radii[2] = std::sqrt(vtkMath::Distance2BetweenPoints(point1.data(), point2.data()));
  double radius = VTK_DOUBLE_MIN;
  for (auto i = 0; i < 3; ++i)
  {
    if (i  == longAxis)
    {
      continue;
    }
    if (radii[i] > radius)
    {
      radius = radii[i];
    }
  }
  radius /= 2.0;
  std::cout << "radii: ";
  for (auto& a : radii)
  {
    std::cout << a << ", ";
  }
  std::cout << std::endl;

  // Create the tree
  auto obbTree =
    vtkSmartPointer<vtkOBBTree>::New();
  obbTree->SetDataSet(polyData);
  obbTree->SetMaxLevel(1);
  obbTree->BuildLocator();

  std::array<double, 3> corner, max, mid, min, size;
  obbTree->ComputeOBB(polyData,
                      corner.data(), max.data(), mid.data(), min.data(), size.data());

  std::array<double, 3>  normalizedX = max;
  vtkMath::Normalize(normalizedX.data());

  auto colors =
    vtkSmartPointer<vtkNamedColors>::New();

  std::array<double,3> endPoint;
  for (auto i = 0; i < 3; ++i)
  {
    endPoint[i] = center[i] + length * normalizedX[i];
  }

  auto lineSource =
    vtkSmartPointer<vtkLineSource>::New();
  lineSource->SetPoint1(center.data());
  lineSource->SetPoint2(endPoint.data());
  lineSource->Print(std::cout);

  auto tube =
    vtkSmartPointer<vtkTubeFilter>::New();
  tube->SetInputConnection(lineSource->GetOutputPort());
  tube->SetRadius(radius/2.0);
  tube->SetNumberOfSides(21);

  auto lineMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  lineMapper->SetInputConnection(lineSource->GetOutputPort());
  auto lineActor =
    vtkSmartPointer<vtkActor>::New();
  lineActor->SetMapper(lineMapper);
  lineActor->GetProperty()->SetColor(colors->GetColor3d("Black").GetData());

  auto sphereStartSource =
    vtkSmartPointer<vtkSphereSource>::New();
  sphereStartSource->SetCenter(center.data());
  sphereStartSource->SetRadius(length*.04);
  auto sphereStartMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  sphereStartMapper->SetInputConnection(sphereStartSource->GetOutputPort());
  auto sphereStart =
    vtkSmartPointer<vtkActor>::New();
  sphereStart->SetMapper(sphereStartMapper);
  sphereStart->GetProperty()->SetColor(colors->GetColor3d("Yellow").GetData());

  auto sphereEndSource =
    vtkSmartPointer<vtkSphereSource>::New();
  sphereEndSource->SetCenter(endPoint.data());
  sphereEndSource->SetRadius(length*.04);
  auto sphereEndMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  sphereEndMapper->SetInputConnection(sphereEndSource->GetOutputPort());
  auto sphereEnd =
    vtkSmartPointer<vtkActor>::New();
  sphereEnd->SetMapper(sphereEndMapper);
  sphereEnd->GetProperty()->SetColor(colors->GetColor3d("Magenta").GetData());

  //Create a mapper and actor for the cylinder
  auto mapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper->SetInputConnection(tube->GetOutputPort());

  auto actor =
    vtkSmartPointer<vtkActor>::New();

  actor->SetMapper(mapper);
  actor->GetProperty()->SetColor(colors->GetColor3d("banana").GetData());
  actor->GetProperty()->SetOpacity(.5);

  auto originalMapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  originalMapper->SetInputData(polyData);
  auto originalActor =
    vtkSmartPointer<vtkActor>::New();
  originalActor->SetMapper(originalMapper);
  originalActor->GetProperty()->SetColor(colors->GetColor3d("tomato").GetData());

  //Create a renderer, render window, and interactor
  auto renderer =
    vtkSmartPointer<vtkRenderer>::New();
  renderer->UseHiddenLineRemovalOn();

  auto renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  renderWindow->SetWindowName("Oriented Cylinder");
  renderWindow->SetSize(640, 480);

  auto renderWindowInteractor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);

  //Add the actor to the scene
  renderer->AddActor(originalActor);
  renderer->AddActor(actor);
  renderer->AddActor(sphereStart);
  renderer->AddActor(sphereEnd);
//  renderer->AddActor(lineActor);
  renderer->SetBackground(colors->GetColor3d("Wheat").GetData());

  //Render and interact
  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
namespace {
vtkSmartPointer<vtkPolyData> ReadPolyData(std::string const& fileName)
{
  vtkSmartPointer<vtkPolyData> polyData;
  std::string extension = "";
  if (fileName.find_last_of(".") != std::string::npos)
  {
    extension = fileName.substr(fileName.find_last_of("."));
  }
  // Make the extension lowercase
  std::transform(extension.begin(), extension.end(), extension.begin(),
                 ::tolower);
  if (extension == ".ply")
  {
    auto reader = vtkSmartPointer<vtkPLYReader>::New();
    reader->SetFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtp")
  {
    auto reader = vtkSmartPointer<vtkXMLPolyDataReader>::New();
    reader->SetFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".obj")
  {
    auto reader = vtkSmartPointer<vtkOBJReader>::New();
    reader->SetFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".stl")
  {
    auto reader = vtkSmartPointer<vtkSTLReader>::New();
    reader->SetFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".vtk")
  {
    auto reader = vtkSmartPointer<vtkPolyDataReader>::New();
    reader->SetFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else if (extension == ".g")
  {
    auto reader = vtkSmartPointer<vtkBYUReader>::New();
    reader->SetGeometryFileName(fileName.c_str());
    reader->Update();
    polyData = reader->GetOutput();
  }
  else
  {
    // Return a polydata sphere if the extension is unknown.
    auto source = vtkSmartPointer<vtkSphereSource>::New();
    source->SetThetaResolution(20);
    source->SetPhiResolution(11);
    source->Update();
    polyData = source->GetOutput();
  }
  return polyData;
}
} // namespace
