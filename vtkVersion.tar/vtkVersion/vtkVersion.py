from __future__ import print_function
import vtk

print(vtk.vtkVersion.GetVTKSourceVersion())
