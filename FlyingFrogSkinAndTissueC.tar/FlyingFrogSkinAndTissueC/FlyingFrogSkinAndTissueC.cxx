// This file is used for tests.
// Generates Figure 12-9c from the VTK textbook.
#include "FlyingFrogSkinAndTissue.cxx"
