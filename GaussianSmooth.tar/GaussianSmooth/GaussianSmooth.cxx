# Show the constant kernel.  Smooth an impulse function.

vtkImageReader reader
reader ReleaseDataFlagOff
reader SetDataExtent 0 255 0 255 1 1
reader SetFilePrefix "$VTK_DATA/heart"
reader SetDataByteOrderToBigEndian

vtkImageCast cast
cast SetInput [reader GetOutput]
cast SetOutputScalarTypeToFloat

vtkImageGaussianSmooth smooth
smooth SetDimensionality 2
smooth SetInput [cast GetOutput]
smooth SetStandardDeviations 4.0 4.0
smooth SetRadiusFactors 2.0 2.0

vtkImageCanvasSource2D imageCanvas
imageCanvas SetScalarType $VTK_FLOAT
imageCanvas SetExtent -10 10 -10 10 0 0

# background zero
imageCanvas SetDrawColor 0
imageCanvas FillBox -10 10 -10 10
# impulse
imageCanvas SetDrawColor 8000
imageCanvas DrawPoint 0 0
 
vtkImageGaussianSmooth smooth2
smooth2 SetDimensionality 2
smooth2 SetInput [imageCanvas GetOutput]
smooth2 SetStandardDeviations 4.0 4.0
smooth2 SetRadiusFactors 3.0 3.0
 
vtkImageMagnify magnify
magnify InterpolateOff
magnify SetMagnificationFactors 5 5 1
magnify SetInput [smooth2 GetOutput]
 
vtkImageViewer2 viewer2
viewer2 SetInput [magnify GetOutput]
viewer2 SetColorWindow 99
viewer2 SetColorLevel 32


vtkImageViewer2 viewer1
viewer1 SetInput [cast GetOutput]
viewer1 SetZSlice 0
viewer1 SetColorWindow 400
viewer1 SetColorLevel 200

vtkImageViewer2 viewer
viewer SetInput [smooth GetOutput]
viewer SetZSlice 0
viewer SetColorWindow 400
viewer SetColorLevel 200






