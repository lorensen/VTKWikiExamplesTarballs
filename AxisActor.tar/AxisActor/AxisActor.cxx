#include "vtkSphereSource.h"
#include "vtkPolyDataMapper.h"
#include "vtkActor.h"
#include "vtkAxisActor.h"
#include "vtkRenderer.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include "vtkCamera.h"
#include "vtkStringArray.h"
#include "vtkSmartPointer.h"
#include <vtkNamedColors.h>

//----------------------------------------------------------------------------
int main( int, char *[] )
{
  vtkSmartPointer<vtkNamedColors> colors =
    vtkSmartPointer<vtkNamedColors>::New();

  // Create the axis actor
  vtkSmartPointer<vtkAxisActor> axis =
    vtkSmartPointer<vtkAxisActor>::New();
  axis->SetPoint1(.5,0,0);
  axis->SetPoint2(1.5,0,0);
  axis->SetBounds(-2, 2, -2, 2, -2, 2);
  axis->SetTickLocationToBoth();
  axis->SetAxisTypeToX();
  axis->SetTitle("A Sphere");
  axis->SetTitleScale(0.5);
  axis->TitleVisibilityOn();
  axis->SetMajorTickSize(0.01);
  axis->SetRange(0,1);
  axis->DrawGridlinesOn();

  vtkSmartPointer<vtkStringArray> labels =
    vtkSmartPointer<vtkStringArray>::New();
  labels->SetNumberOfTuples(1);
  labels->SetValue(0,"x Axis");

  axis->SetLabels(labels);
  axis->SetLabelScale(.5);
  axis->MinorTicksVisibleOn();
  axis->SetDeltaMajor(0,.1);
  axis->SetCalculateTitleOffset(0);
  axis->SetCalculateLabelOffset(0);
  axis->Print(std::cout);

  vtkSmartPointer<vtkSphereSource> source =
    vtkSmartPointer<vtkSphereSource>::New();
  source->SetCenter(1,1,1);
  vtkSmartPointer<vtkPolyDataMapper> mapper =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper->SetInputConnection(source->GetOutputPort());

 vtkSmartPointer<vtkActor> actor =
    vtkSmartPointer<vtkActor>::New();
 actor->SetMapper(mapper);

  // Create the RenderWindow, Renderer and both Actors
  vtkSmartPointer<vtkRenderer> renderer =
    vtkSmartPointer<vtkRenderer>::New();
  vtkSmartPointer<vtkRenderWindow> renderWindow =
    vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  vtkSmartPointer<vtkRenderWindowInteractor> interactor =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  interactor->SetRenderWindow(renderWindow);

  axis->SetCamera(renderer->GetActiveCamera());

  renderer->AddActor(actor);
  renderer->AddActor(axis);

  renderer->SetBackground(.3, .4, .5);
  renderWindow->SetSize(640, 480);
  renderer->ResetCamera();
  renderer->ResetCameraClippingRange();

  // render the image
  renderWindow->Render();

  interactor->Start();

  return EXIT_SUCCESS;
}
