#include <vtkSmartPointer.h>
#include <vtkLightKit.h>

#include <vtkSuperquadricSource.h>

#include <vtkLightCollection.h>
#include <vtkProperty.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkPlaneSource.h>
#include <vtkSphereSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkLight.h>
#include <vtkLightActor.h>
#include <vtkRenderWindowInteractor.h>

int main(int, char *[])
{
  vtkSmartPointer<vtkRenderer> renderer =
    vtkSmartPointer<vtkRenderer>::New();

  vtkSmartPointer<vtkLightKit> lightKit =
    vtkSmartPointer<vtkLightKit>::New();
  lightKit->SetKeyLightWarmth(0.0);
  lightKit->SetFillLightWarmth(1.0);
  lightKit->SetHeadLightWarmth(.7);
  lightKit->AddLightsToRenderer(renderer);

  vtkLightCollection* originalLights = renderer->GetLights();
  std::cout << "Originally there are " << originalLights->GetNumberOfItems() << " lights." << std::endl;

  // Create a plane for the light to shine on
  vtkSmartPointer<vtkPlaneSource> planeSource = vtkSmartPointer<vtkPlaneSource>::New();
  planeSource->SetResolution(100, 100);
  planeSource->Update();

  vtkSmartPointer<vtkPolyDataMapper> planeMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
  planeMapper->SetInputData(planeSource->GetOutput());

  vtkSmartPointer<vtkActor> planeActor = vtkSmartPointer<vtkActor>::New();
  planeActor->SetMapper(planeMapper);
  renderer->AddActor(planeActor);

  // Create a superquadric
  vtkSmartPointer<vtkSuperquadricSource> squad =
    vtkSmartPointer<vtkSuperquadricSource>::New();
  squad->SetPhiResolution(20);
  squad->SetThetaResolution(25);
  squad->SetPhiRoundness(1.5);
  squad->SetThickness(0.43);
  squad->SetThetaRoundness(0.7);
  squad->ToroidalOn();

  vtkSmartPointer<vtkPolyDataMapper> squadMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
  squadMapper->SetInputConnection(squad->GetOutputPort());

  vtkSmartPointer<vtkActor> squadActor = vtkSmartPointer<vtkActor>::New();
  squadActor->SetMapper(squadMapper);
  renderer->AddActor(squadActor);

  vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);

  vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor =
      vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);

  renderWindow->Render();
  std::cout << "Now there are " << originalLights->GetNumberOfItems() << " lights." << std::endl;

  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
