#include <vtkSmartPointer.h>
#include <vtkLightKit.h>

#include <vtkSuperquadricSource.h>

#include <vtkLightCollection.h>
#include <vtkProperty.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkPlaneSource.h>
#include <vtkSphereSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkLight.h>
#include <vtkLightActor.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkNamedColors.h>

int main(int, char *[])
{
  auto renderer =
    vtkSmartPointer<vtkRenderer>::New();

  auto lightKit =
    vtkSmartPointer<vtkLightKit>::New();
  lightKit->SetKeyLightWarmth(0.0);
  lightKit->SetFillLightWarmth(1.0);
  lightKit->SetHeadLightWarmth(.7);
  lightKit->AddLightsToRenderer(renderer);

  vtkLightCollection* originalLights = renderer->GetLights();
  std::cout << "Originally there are " << originalLights->GetNumberOfItems() << " lights." << std::endl;

  // Create a plane for the light to shine on
  auto planeSource = vtkSmartPointer<vtkPlaneSource>::New();
  planeSource->SetResolution(100, 100);
  planeSource->Update();

  auto planeMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
  planeMapper->SetInputData(planeSource->GetOutput());

  auto planeActor = vtkSmartPointer<vtkActor>::New();
  planeActor->SetMapper(planeMapper);
  renderer->AddActor(planeActor);

  // Create a superquadric
  auto squad =
    vtkSmartPointer<vtkSuperquadricSource>::New();
  squad->SetPhiResolution(20);
  squad->SetThetaResolution(25);
  squad->SetPhiRoundness(1.5);
  squad->SetThickness(0.43);
  squad->SetThetaRoundness(0.7);
  squad->ToroidalOn();

  auto squadMapper = vtkSmartPointer<vtkPolyDataMapper>::New();
  squadMapper->SetInputConnection(squad->GetOutputPort());

  auto squadActor = vtkSmartPointer<vtkActor>::New();
  squadActor->SetMapper(squadMapper);

  auto colors =
    vtkSmartPointer<vtkNamedColors>::New();
  renderer->AddActor(squadActor);
  renderer->SetBackground(colors->GetColor3d("Wheat").GetData());

  auto renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
  renderWindow->AddRenderer(renderer);
  renderWindow->SetSize(640, 480);

  auto renderWindowInteractor =
      vtkSmartPointer<vtkRenderWindowInteractor>::New();
  renderWindowInteractor->SetRenderWindow(renderWindow);

  renderWindow->Render();
  std::cout << "Now there are " << originalLights->GetNumberOfItems() << " lights." << std::endl;

  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
