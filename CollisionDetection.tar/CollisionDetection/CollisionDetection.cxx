#include <vtkSmartPointer.h>
#include <vtkCollisionDetectionFilter.h>

#include <vtkSphereSource.h>
#include <vtkTransform.h>
#include <vtkDataSetAttributes.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkProperty.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>

#include <vtkNamedColors.h>

#include <sstream>

int main (int, char*[])
{

  vtkSmartPointer<vtkCollisionDetectionFilter> collision =
    vtkSmartPointer<vtkCollisionDetectionFilter>::New();

  vtkSmartPointer<vtkSphereSource> sphere1 =
    vtkSmartPointer<vtkSphereSource>::New();
  sphere1->SetRadius(5.0);
  sphere1->SetPhiResolution(21);
  sphere1->SetThetaResolution(21);
  vtkSmartPointer<vtkSphereSource> sphere2 =
    vtkSmartPointer<vtkSphereSource>::New();
  sphere2->SetRadius(5.0);
  sphere2->SetCenter(4.9, 0.0, 0.0);
  sphere2->SetPhiResolution(21);
  sphere2->SetThetaResolution(21);

  collision->SetInputConnection(0, sphere1->GetOutputPort());
  collision->SetInputConnection(1, sphere2->GetOutputPort());
  vtkSmartPointer<vtkTransform> transform1 =
    vtkSmartPointer<vtkTransform>::New();
  vtkSmartPointer<vtkTransform> transform2 =
    vtkSmartPointer<vtkTransform>::New();
  collision->SetTransform(0, transform1);
  collision->SetTransform(1, transform2);
  collision->GenerateScalarsOn();
  collision->SetBoxTolerance(.00001);
#if 0
  collision->SetInputArrayToProcess(0, 0, 0,
                                   vtkDataObject::FIELD_ASSOCIATION_CELLS,
                                   vtkDataSetAttributes::SCALARS);
#endif
  collision->Update();

  collision->GetOutput(0)->Print(std::cout); 
  collision->GetOutput(1)->Print(std::cout); 
  collision->GetOutput(2)->Print(std::cout); 

  vtkSmartPointer<vtkNamedColors> colors =
    vtkSmartPointer<vtkNamedColors>::New();

  vtkSmartPointer<vtkRenderer> ren =
    vtkSmartPointer<vtkRenderer>::New();
  vtkSmartPointer<vtkRenderWindow> renWin =
    vtkSmartPointer<vtkRenderWindow>::New();
  vtkSmartPointer<vtkRenderWindowInteractor> iren =
    vtkSmartPointer<vtkRenderWindowInteractor>::New();
  iren->SetRenderWindow(renWin);

  vtkSmartPointer<vtkPolyDataMapper> mapper1 =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper1->SetInputData(collision->GetOutput(0));
  vtkSmartPointer<vtkPolyDataMapper> mapper2 =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper2->SetInputData(collision->GetOutput(1));
  vtkSmartPointer<vtkPolyDataMapper> mapper3 =
    vtkSmartPointer<vtkPolyDataMapper>::New();
  mapper3->SetInputData(collision->GetOutput(2));

  vtkSmartPointer<vtkActor> actor1 =
    vtkSmartPointer<vtkActor>::New();
  vtkSmartPointer<vtkActor> actor2 =
    vtkSmartPointer<vtkActor>::New();
  actor2->GetProperty()->SetColor(colors->GetColor3d("tomato").GetData());
  actor2->GetProperty()->SetOpacity(.5);
  vtkSmartPointer<vtkActor> actor3 =
    vtkSmartPointer<vtkActor>::New();
  actor3->GetProperty()->SetLineWidth(5);
  actor3->GetProperty()->SetColor(colors->GetColor3d("banana").GetData());

  actor1->SetMapper(mapper1);
  actor2->SetMapper(mapper2);
  actor3->SetMapper(mapper3);

  // Add the actors to the renderer
//  ren->AddActor(actor1);
//  ren->AddActor(actor2);
  ren->AddActor(actor3);

  ren->ResetCamera();
  ren->SetBackground(colors->GetColor3d("SlateGray").GetData());
  renWin->AddRenderer(ren);

  // This starts the event loop and as a side effect causes an initial
  // render.

  renWin->SetSize(640, 480);
  renWin->Render();
  iren->Start();
  return EXIT_SUCCESS;
}
