#include <vtkSmartPointer.h>

int main(int, char *[])
{
  
  return EXIT_SUCCESS;
}
